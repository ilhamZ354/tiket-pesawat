<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tourism Site</title>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
</head>
<body>
    <div class="container-fluid p-0">

        <!-- Hero Section -->
        <div class="navbar">
            <ul class="nav text-secondary">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Wisata</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Tiketmu</a>
                </li>
            </ul>
        </div>

        <div class="jumbotron jumbotron-fluid p-0">
            <div class="hero-image-container">
                <img src="assets/danautoba2.jpeg" class="img-fluid w-100" alt="Nature">
                <div class="hero-overlay"></div>
            </div>
            <div class="container text-white position-absolute top-50 start-50 translate-middle">
                <p class="display-5"><strong>Temukan</strong> Lokasi <strong>Healing</strong> Terbaik</p>
                <h1 class="display-5">Untukmu dan Keluargamu..</h1>
            </div>
        </div>

        <!-- Destinations Section -->
        <div class="container mt-4">
            <div class="row">
                <div class="col-3">
                    <div class="card">
                        <img src="assets/bromo.jpeg" class="card-img-top" alt="Bromo">
                        <div class="card-body">
                            <h5 class="card-title">Bromo</h5>
                            <p class="card-text">Gunung Bromo, Jawa Timur</p>
                            <p class="card-text"><strong>IDR 120.000/orang</strong></p>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="card">
                        <img src="assets/danautoba.jpeg" class="card-img-top" alt="Danau Toba">
                        <div class="card-body">
                            <h5 class="card-title">Danau Toba</h5>
                            <p class="card-text">Danau Toba, Sumatera Utara</p>
                            <p class="card-text"><strong>IDR 80.000/orang</strong></p>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="card">
                        <img src="assets/raja-ampat.jpeg" class="card-img-top" alt="Raja Ampat">
                        <div class="card-body">
                            <h5 class="card-title">Raja Ampat</h5>
                            <p class="card-text">Raja Ampat, Papua</p>
                            <p class="card-text"><strong>IDR 250.000/orang</strong></p>
                        </div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="card">
                        <img src="assets/komodo.jpeg" class="card-img-top" alt="Komodo">
                        <div class="card-body">
                            <h5 class="card-title">Taman Nasional Komodo</h5>
                            <p class="card-text">Pulau Komodo, NTT</p>
                            <p class="card-text"><strong>IDR 100.000/orang</strong></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon-6.0.0\www\tiket-pesawat\tiket-pesawat-app\resources\views/welcome.blade.php ENDPATH**/ ?>